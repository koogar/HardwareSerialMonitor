# HardwareSerialMonitor
Gnat Stats PC Harware Performance Monitor Windows Client
  
  GNATSTATS OLED PC Performance Monitor / HardwareSerialMonitor -  Rupert Hirst & Colin Conway © 2016-2018
  http://tallmanlabs.com  & http://runawaybrainz.blogspot.com/
  
  https://hackaday.io/project/19018-gnat-stats-tiny-oled-pc-performance-monitor

  Licence
  -------

  Attribution-NonCommercial-ShareAlike  CC BY-NC-SA

  This license lets others remix, tweak, and build upon your work non-commercially, as long as they credit you and license their new creations under the identical terms.

  https://creativecommons.org/licenses/
