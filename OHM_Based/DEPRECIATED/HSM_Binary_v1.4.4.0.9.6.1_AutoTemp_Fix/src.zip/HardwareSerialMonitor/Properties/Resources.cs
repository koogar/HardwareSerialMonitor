﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace HardwareSerialMonitor.Properties
{
	// Token: 0x02000006 RID: 6
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000033 RID: 51 RVA: 0x0000483F File Offset: 0x00002A3F
		internal Resources()
		{
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000034 RID: 52 RVA: 0x00004847 File Offset: 0x00002A47
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("HardwareSerialMonitor.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000035 RID: 53 RVA: 0x00004873 File Offset: 0x00002A73
		// (set) Token: 0x06000036 RID: 54 RVA: 0x0000487A File Offset: 0x00002A7A
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000037 RID: 55 RVA: 0x00004882 File Offset: 0x00002A82
		internal static Bitmap About_Image_Side_Tacho
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("About Image Side Tacho", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000038 RID: 56 RVA: 0x0000489D File Offset: 0x00002A9D
		internal static Bitmap Exit
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Exit", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000039 RID: 57 RVA: 0x000048B8 File Offset: 0x00002AB8
		internal static Bitmap info
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("info", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600003A RID: 58 RVA: 0x000048D3 File Offset: 0x00002AD3
		internal static Bitmap Serial
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Serial", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600003B RID: 59 RVA: 0x000048EE File Offset: 0x00002AEE
		internal static Icon TrayIcon1
		{
			get
			{
				return (Icon)Resources.ResourceManager.GetObject("TrayIcon1", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600003C RID: 60 RVA: 0x00004909 File Offset: 0x00002B09
		internal static Icon TrayIconGreen
		{
			get
			{
				return (Icon)Resources.ResourceManager.GetObject("TrayIconGreen", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600003D RID: 61 RVA: 0x00004924 File Offset: 0x00002B24
		internal static Icon TrayIconRed
		{
			get
			{
				return (Icon)Resources.ResourceManager.GetObject("TrayIconRed", Resources.resourceCulture);
			}
		}

		// Token: 0x04000026 RID: 38
		private static ResourceManager resourceMan;

		// Token: 0x04000027 RID: 39
		private static CultureInfo resourceCulture;
	}
}
