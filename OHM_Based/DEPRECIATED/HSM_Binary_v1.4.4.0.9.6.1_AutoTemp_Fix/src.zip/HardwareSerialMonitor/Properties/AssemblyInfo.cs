﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyTitle("HardwareSerialMonitor PC performance monitor")]
[assembly: AssemblyDescription("Visual Studio Application written by Colin Conway and Rupert Hirst Visual Studio project source code kindly shared by psyrax see: https://github.com/psyrax/SerialMonitor Open Hardware Monitor Copyright © MPL v2 2010 - 2014 Michael Möller http://openhardwaremonitor.org/")]
[assembly: AssemblyConfiguration("Visual Studio Application written by Colin Conway and Rupert Hirst. Visual Studio project source code, kindly shared by psyrax see: https://github.com/psyrax/SerialMonitor")]
[assembly: AssemblyCompany("Tallman Labs")]
[assembly: AssemblyProduct("HardwareSerialMonitor")]
[assembly: AssemblyCopyright("Copyright ©  GPL v3 2016")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("6719b22b-c5ec-498f-9d1a-328f39fff467")]
[assembly: AssemblyFileVersion("1.1.0.0")]
