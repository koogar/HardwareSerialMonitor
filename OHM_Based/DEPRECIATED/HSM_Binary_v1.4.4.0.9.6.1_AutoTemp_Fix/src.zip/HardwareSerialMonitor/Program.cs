﻿using System;
using System.Windows.Forms;

namespace HardwareSerialMonitor
{
	// Token: 0x02000004 RID: 4
	internal static class Program
	{
		// Token: 0x0600002C RID: 44 RVA: 0x00004797 File Offset: 0x00002997
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1());
		}
	}
}
