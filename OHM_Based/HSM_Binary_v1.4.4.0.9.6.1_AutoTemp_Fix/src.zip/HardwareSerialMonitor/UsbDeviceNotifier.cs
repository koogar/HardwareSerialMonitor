﻿using System;
using System.Runtime.InteropServices;

namespace HardwareSerialMonitor
{
	// Token: 0x02000005 RID: 5
	internal class UsbDeviceNotifier
	{
		// Token: 0x0600002D RID: 45 RVA: 0x000047B0 File Offset: 0x000029B0
		public static void RegisterUsbDeviceNotification(IntPtr windowHandle)
		{
			UsbDeviceNotifier.DevBroadcastDeviceinterface dbi = new UsbDeviceNotifier.DevBroadcastDeviceinterface
			{
				DeviceType = 5,
				Reserved = 0,
				ClassGuid = UsbDeviceNotifier.GuidDevinterfaceUSBDevice,
				Name = 0
			};
			dbi.Size = Marshal.SizeOf<UsbDeviceNotifier.DevBroadcastDeviceinterface>(dbi);
			IntPtr buffer = Marshal.AllocHGlobal(dbi.Size);
			Marshal.StructureToPtr<UsbDeviceNotifier.DevBroadcastDeviceinterface>(dbi, buffer, true);
			UsbDeviceNotifier.notificationHandle = UsbDeviceNotifier.RegisterDeviceNotification(windowHandle, buffer, 0);
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00004819 File Offset: 0x00002A19
		public static void UnregisterUsbDeviceNotification()
		{
			UsbDeviceNotifier.UnregisterDeviceNotification(UsbDeviceNotifier.notificationHandle);
		}

		// Token: 0x0600002F RID: 47
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr RegisterDeviceNotification(IntPtr recipient, IntPtr notificationFilter, int flags);

		// Token: 0x06000030 RID: 48
		[DllImport("user32.dll")]
		private static extern bool UnregisterDeviceNotification(IntPtr handle);

		// Token: 0x04000020 RID: 32
		public const int DbtDevicearrival = 32768;

		// Token: 0x04000021 RID: 33
		public const int DbtDeviceremovecomplete = 32772;

		// Token: 0x04000022 RID: 34
		public const int WmDevicechange = 537;

		// Token: 0x04000023 RID: 35
		private const int DbtDevtypDeviceinterface = 5;

		// Token: 0x04000024 RID: 36
		private static readonly Guid GuidDevinterfaceUSBDevice = new Guid("A5DCBF10-6530-11D2-901F-00C04FB951ED");

		// Token: 0x04000025 RID: 37
		private static IntPtr notificationHandle;

		// Token: 0x0200000A RID: 10
		private struct DevBroadcastDeviceinterface
		{
			// Token: 0x04000030 RID: 48
			internal int Size;

			// Token: 0x04000031 RID: 49
			internal int DeviceType;

			// Token: 0x04000032 RID: 50
			internal int Reserved;

			// Token: 0x04000033 RID: 51
			internal Guid ClassGuid;

			// Token: 0x04000034 RID: 52
			internal short Name;
		}
	}
}
