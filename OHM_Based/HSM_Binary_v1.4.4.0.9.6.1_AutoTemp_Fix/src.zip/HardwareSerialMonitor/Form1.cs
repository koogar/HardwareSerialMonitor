﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Management;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using HardwareSerialMonitor.Properties;
using IniParser;
using IniParser.Model;
using OpenHardwareMonitor.Hardware;

namespace HardwareSerialMonitor
{
	// Token: 0x02000003 RID: 3
	public partial class Form1 : Form
	{
		// Token: 0x06000011 RID: 17 RVA: 0x00002B38 File Offset: 0x00000D38
		public Form1()
		{
			this.thisComputer = new Computer();
			this.thisComputer.CPUEnabled = true;
			this.thisComputer.GPUEnabled = true;
			this.thisComputer.HDDEnabled = true;
			this.thisComputer.MainboardEnabled = true;
			this.thisComputer.RAMEnabled = true;
			this.thisComputer.Open();
			this.InitializeComponent();
			this.trayIcon = Resources.TrayIcon1;
			this.ApplicationIcon = new NotifyIcon();
			this.ApplicationIcon.Icon = this.trayIcon;
			this.ApplicationIcon.Visible = true;
			this.ApplicationIcon.BalloonTipIcon = ToolTipIcon.Info;
			this.ApplicationIcon.BalloonTipText = "HSM";
			this.ApplicationIcon.BalloonTipTitle = "HSM";
			base.WindowState = FormWindowState.Minimized;
			base.ShowInTaskbar = false;
			base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
			base.ControlBox = false;
			base.Opacity = 0.0;
			base.Hide();
			this.ApplicationIcon.ContextMenuStrip = this.menu;
			this.ApplicationIcon.MouseUp += this.ApplicationIcon_MouseUp;
			this.connectionTimer1.Interval = Form1.dataCheckInterval;
			this.connectionTimer1.Tick += this.connectionTimer1_Tick;
			this.connectionTimer1.Start();
			UsbDeviceNotifier.RegisterUsbDeviceNotification(base.Handle);
			this.checkDevice();
			this.CreateMenuItems();
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002CF8 File Offset: 0x00000EF8
		private void connectionTimer1_Tick(object sender, EventArgs e)
		{
			if (this.AutomaticPortSelect)
			{
				if (this.isAttached)
				{
					this.isConnected = this.ConnectToDevice();
				}
				if (this.isConnected)
				{
					this.ApplicationIcon.Icon = Resources.TrayIconGreen;
					this.trayIcon.Equals(Resources.TrayIcon1);
					this.dataCheck();
				}
				else
				{
					this.ApplicationIcon.Icon = Resources.TrayIconRed;
				}
			}
			if (this.ManualPortSelect)
			{
				this.dataCheck();
				if (!this.trayIcon.Equals(Resources.TrayIcon1))
				{
					this.ApplicationIcon.Icon = Resources.TrayIcon1;
				}
			}
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002D92 File Offset: 0x00000F92
		private void ApplicationIcon_MouseUp(object sender, MouseEventArgs e)
		{
			this.InvalidateMenu(this.menu);
			if (e.Button == MouseButtons.Left)
			{
				typeof(NotifyIcon).GetMethod("ShowContextMenu", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(this.ApplicationIcon, null);
			}
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002DD0 File Offset: 0x00000FD0
		private void CreateMenuItems()
		{
			string AutoText = string.Empty;
			ToolStripMenuItem item = new ToolStripMenuItem();
			if (this.AutomaticPortSelect && Form1.mySerialPort != null)
			{
				string AutoDeviceName = this.getDeviceName(Form1.mySerialPort.PortName.ToString());
				AutoText = string.Concat(new string[]
				{
					"Automatic | ",
					AutoDeviceName,
					" (",
					Form1.mySerialPort.PortName.ToString(),
					")"
				});
			}
			else
			{
				AutoText = "Automatic Mode";
			}
			item.Text = AutoText;
			if (this.AutomaticPortSelect)
			{
				item.Checked = true;
			}
			else
			{
				item.Checked = false;
			}
			item.Click += this.Item_Click;
			this.menu.Items.Add(item);
			item = new ToolStripMenuItem();
			item.Text = "Serial Ports Available";
			ToolStripSeparator sep = new ToolStripSeparator();
			this.menu.Items.Add(sep);
			this.menu.Items.Add(item);
			string[] portNames = SerialPort.GetPortNames();
			for (int i = 0; i < portNames.Length; i++)
			{
				string port = portNames[i];
				string portName = port;
				string regexPattern = "\\D*(\\d+)\\D*";
				portName = "COM" + Regex.Replace(portName, regexPattern, "$1");
				item = new ToolStripMenuItem();
				string deviceName = this.getDeviceName(portName);
				item.Text = portName + " | " + deviceName;
				if (portName == this.portSelected)
				{
					item.Checked = true;
				}
				else
				{
					item.Checked = false;
				}
				item.Click += delegate(object sender, EventArgs e)
				{
					this.Selected_Serial(sender, e, portName);
				};
				item.Image = Resources.Serial;
				this.menu.Items.Add(item);
			}
			sep = new ToolStripSeparator();
			this.menu.Items.Add(sep);
			item = new ToolStripMenuItem();
			item.Text = "Refresh";
			item.Click += this.refresh_Click;
			this.menu.Items.Add(item);
			sep = new ToolStripSeparator();
			this.menu.Items.Add(sep);
			item = new ToolStripMenuItem();
			item.Text = "About";
			item.Click += this.About_Click;
			item.Image = Resources.info;
			this.menu.Items.Add(item);
			sep = new ToolStripSeparator();
			this.menu.Items.Add(sep);
			item = new ToolStripMenuItem();
			item.Text = "Exit";
			item.Click += this.Exit_Click;
			item.Image = Resources.Exit;
			this.menu.Items.Add(item);
		}

		// Token: 0x06000015 RID: 21 RVA: 0x000030B7 File Offset: 0x000012B7
		private void refresh_Click(object sender, EventArgs e)
		{
			this.InvalidateMenu(this.menu);
			typeof(NotifyIcon).GetMethod("ShowContextMenu", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(this.ApplicationIcon, null);
		}

		// Token: 0x06000016 RID: 22 RVA: 0x000030E8 File Offset: 0x000012E8
		private void About_Click(object sender, EventArgs e)
		{
			new AboutBox1().Show();
		}

		// Token: 0x06000017 RID: 23 RVA: 0x000030F4 File Offset: 0x000012F4
		private void Item_Click(object sender, EventArgs e)
		{
			this.ManualPortSelect = false;
			this.AutomaticPortSelect = true;
			this.portSelected = string.Empty;
			try
			{
				if (Form1.mySerialPort.IsOpen)
				{
					Form1.mySerialPort.Close();
				}
				if (this.manualIsAttached)
				{
					this.isAttached = true;
					this.manualIsAttached = false;
					this.Vid_Pid = this.SPortVid_Pid;
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00003168 File Offset: 0x00001368
		private void InvalidateMenu(ContextMenuStrip menu)
		{
			menu.Items.Clear();
			this.CreateMenuItems();
		}

		// Token: 0x06000019 RID: 25 RVA: 0x0000317C File Offset: 0x0000137C
		private void Selected_Serial(object sender, EventArgs e, string selected_port)
		{
			string regexPattern = "\\D*(\\d+)\\D*";
			selected_port = "COM" + Regex.Replace(selected_port, regexPattern, "$1");
			this.manualIsAttached = true;
			this.SPortVid_Pid = this.getVidPid(selected_port);
			Form1.devID = this.getDeviceID(selected_port);
			int indexOfVID = this.SPortVid_Pid.IndexOf("_") + 1;
			int indexOfPID = this.SPortVid_Pid.IndexOf("_", indexOfVID) + 1;
			if (this.SPortVid_Pid.Contains("BTHENUM"))
			{
				Form1.VID = "";
				Form1.PID = "";
			}
			try
			{
				Form1.VID = this.SPortVid_Pid.Substring(indexOfVID, 4);
				Form1.PID = this.SPortVid_Pid.Substring(indexOfPID, 4);
				Form1.ModifyINIData("VendorID", Form1.VID.ToString());
				Form1.ModifyINIData("ProductID", Form1.PID.ToString());
			}
			catch (Exception)
			{
			}
			Form1.ModifyINIData("DeviceID", Form1.devID.ToString());
			try
			{
				if (Form1.mySerialPort.IsOpen)
				{
					Form1.mySerialPort.Close();
				}
			}
			catch
			{
			}
			if (this.AutomaticPortSelect)
			{
				this.AutomaticPortSelect = false;
			}
			if (!this.ManualPortSelect)
			{
				this.ManualPortSelect = true;
			}
			this.portSelected = selected_port;
			Console.WriteLine("Selected port: " + selected_port);
			Form1.mySerialPort = new SerialPort(selected_port, 9600, Parity.None, 8, StopBits.One);
			Form1.mySerialPort.ReadTimeout = 500;
			Form1.mySerialPort.WriteTimeout = 500;
			Form1.mySerialPort.DtrEnable = true;
			Form1.mySerialPort.RtsEnable = true;
			try
			{
				if (!Form1.mySerialPort.IsOpen)
				{
					Form1.mySerialPort.Open();
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00003354 File Offset: 0x00001554
		private void Selected_Serial(string selected_port)
		{
			string regexPattern = "\\D*(\\d+)\\D*";
			selected_port = "COM" + Regex.Replace(selected_port, regexPattern, "$1");
			try
			{
				if (Form1.mySerialPort.IsOpen)
				{
					Form1.mySerialPort.Close();
				}
			}
			catch
			{
			}
			if (this.AutomaticPortSelect)
			{
				this.AutomaticPortSelect = false;
			}
			if (!this.ManualPortSelect)
			{
				this.ManualPortSelect = true;
			}
			this.portSelected = selected_port;
			Console.WriteLine("Selected port: " + selected_port);
			Form1.mySerialPort = new SerialPort(selected_port, 9600, Parity.None, 8, StopBits.One);
			Form1.mySerialPort.ReadTimeout = 500;
			Form1.mySerialPort.WriteTimeout = 500;
			Form1.mySerialPort.DtrEnable = true;
			Form1.mySerialPort.RtsEnable = true;
			this.manualIsAttached = true;
			try
			{
				if (!Form1.mySerialPort.IsOpen)
				{
					Form1.mySerialPort.Open();
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600001B RID: 27 RVA: 0x00003454 File Offset: 0x00001654
		private void dataCheck()
		{
			string cpuName = "CPU";
			string cpuTemp = "C";
			string cpuLoad = "c";
			string ramLoad = "RL";
			string ramUsed = "R";
			string ramAvailable = "RA";
			string gpuName = "GPU";
			string gpuTemp = "G";
			string gpuLoad = "c";
			string gpuCoreClock = "GCC";
			string gpuMemoryClock = "GCM";
			string gpuShaderClock = "GSC";
			string gpuMemTotal = "GMT";
			string gpuMemUsed = "GMU";
			string gpuMemLoad = "GML";
			string gpuFanSpeedLoad = "GFANL";
			string gpuFanSpeedRPM = "GRPM";
			string gpuPower = "GPWR";
			string cpuClock = "";
			int highestCPUClock = 0;
			foreach (IHardware hw in this.thisComputer.Hardware)
			{
				if (hw.HardwareType.ToString().IndexOf("CPU") > -1)
				{
					cpuName = "CPU:";
					cpuName += hw.Name;
				}
				else if (hw.HardwareType.ToString().IndexOf("Gpu") > -1)
				{
					gpuName = "GPU:";
					gpuName += hw.Name;
				}
				hw.Update();
				foreach (ISensor s in hw.Sensors)
				{
					if (s.SensorType == SensorType.Temperature && s.Value != null)
					{
						int curTemp = (int)s.Value.Value;
						string name = s.Name;
						if (!(name == "CPU Package"))
						{
							if (name == "GPU Core")
							{
								gpuTemp = curTemp.ToString();
							}
						}
						else
						{
							cpuTemp = curTemp.ToString();
						}
					}
					if (s.SensorType == SensorType.Clock && s.Value != null)
					{
						int clockSpeed = (int)s.Value.Value;
						string name = s.Name;
						if (!(name == "GPU Core"))
						{
							if (!(name == "GPU Memory"))
							{
								if (name == "GPU Shader")
								{
									gpuShaderClock = "|GSC" + clockSpeed.ToString();
								}
							}
							else
							{
								gpuMemoryClock = "|GMC" + clockSpeed.ToString();
							}
						}
						else
						{
							gpuCoreClock = "|GCC" + clockSpeed.ToString();
						}
						if (s.Name.IndexOf("CPU Core") > -1 && clockSpeed > highestCPUClock)
						{
							highestCPUClock = clockSpeed;
							cpuClock = "|CHC" + highestCPUClock.ToString() + "|";
						}
					}
					if (s.SensorType == SensorType.Load && s.Value != null)
					{
						int curLoad = (int)s.Value.Value;
						string name = s.Name;
						if (!(name == "CPU Total"))
						{
							if (!(name == "GPU Core"))
							{
								if (!(name == "Memory"))
								{
									if (name == "GPU Memory")
									{
										gpuMemLoad = curLoad.ToString();
									}
								}
								else
								{
									ramLoad = curLoad.ToString();
								}
							}
							else
							{
								gpuLoad = curLoad.ToString();
							}
						}
						else
						{
							cpuLoad = curLoad.ToString();
						}
					}
					if (s.SensorType == SensorType.Data && s.Value != null && s.Name == "Available Memory")
					{
						ramAvailable = Math.Round((decimal)s.Value.Value, 1).ToString();
					}
					if (s.SensorType == SensorType.Data && s.Value != null && s.Name == "Used Memory")
					{
						ramUsed = Math.Round((decimal)s.Value.Value, 1).ToString();
					}
					if (s.SensorType == SensorType.SmallData && s.Value != null && s.Name == "GPU Memory Total")
					{
						gpuMemTotal = Math.Round((decimal)s.Value.Value, 0).ToString();
					}
					if (s.SensorType == SensorType.SmallData && s.Value != null && s.Name == "GPU Memory Used")
					{
						gpuMemUsed = Math.Round((decimal)s.Value.Value, 0).ToString();
					}
					if (s.SensorType == SensorType.Fan && s.Value != null && s.Name == "GPU")
					{
						gpuFanSpeedRPM = Math.Round((decimal)s.Value.Value, 1).ToString();
					}
					if (s.SensorType == SensorType.Control && s.Value != null && s.Name == "GPU Fan")
					{
						gpuFanSpeedLoad = Math.Round((decimal)s.Value.Value, 1).ToString();
					}
					if (s.SensorType == SensorType.Power && s.Value != null && s.Name == "GPU Power")
					{
						gpuPower = Math.Round((decimal)s.Value.Value, 1).ToString();
					}
					if (s.SensorType == SensorType.Control && s.Value != null && s.Name == "CPU Fan")
					{
						Math.Round((decimal)s.Value.Value, 1).ToString();
					}
				}
				if (cpuTemp == "")
				{
					foreach (ISensor s2 in hw.Sensors)
					{
						int numTemps = 0;
						int averageTemp = 0;
						try
						{
							if (s2.SensorType == SensorType.Temperature && s2.Name.IndexOf("CPU Core") > -1)
							{
								averageTemp += (int)s2.Value.Value;
								numTemps++;
							}
							if (numTemps > 0)
							{
								cpuTemp = (averageTemp / numTemps).ToString();
							}
						}
						catch
						{
						}
					}
				}
			}
			string stats = string.Empty;
			stats = string.Concat(new string[]
			{
				"C",
				cpuTemp,
				"c ",
				cpuLoad,
				"%|G",
				gpuTemp,
				"c ",
				gpuLoad,
				"%|R",
				ramUsed,
				"GB|RA",
				ramAvailable,
				"|RL",
				ramLoad,
				"|GMT",
				gpuMemTotal,
				"|GMU",
				gpuMemUsed,
				"|GML",
				gpuMemLoad,
				"|GFANL",
				gpuFanSpeedLoad,
				"|GRPM",
				gpuFanSpeedRPM,
				"|GPWR",
				gpuPower,
				"|"
			});
			if (stats != string.Empty)
			{
				this.sendToArduino(string.Concat(new string[]
				{
					stats,
					cpuName,
					gpuName,
					gpuCoreClock,
					gpuMemoryClock,
					gpuShaderClock,
					cpuClock
				}));
			}
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00003BF4 File Offset: 0x00001DF4
		private bool ConnectToDevice()
		{
			string[] portNames = SerialPort.GetPortNames();
			string sInstanceName = string.Empty;
			string sPortName = string.Empty;
			bool bFound = false;
			for (int y = 0; y < portNames.Length; y++)
			{
				try
				{
					foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_PnPEntity WHERE ClassGuid='{4d36e978-e325-11ce-bfc1-08002be10318}'").Get())
					{
						ManagementObject queryObj = (ManagementObject)managementBaseObject;
						sInstanceName = queryObj["PNPDeviceID"].ToString().ToUpper();
						if (Form1.devID != string.Empty)
						{
							if (sInstanceName.IndexOf(this.Vid_Pid) > -1 && sInstanceName.IndexOf(Form1.devID) > -1)
							{
								if (!this.isConnected && !bFound)
								{
									string name = queryObj["Name"].ToString();
									if (name.Contains("COM"))
									{
										int indexOfCOM = name.IndexOf("COM");
										int indexEndOfCOM = name.IndexOf(")", indexOfCOM);
										sPortName = name.Substring(indexOfCOM, indexEndOfCOM - indexOfCOM);
									}
									Form1.mySerialPort = new SerialPort(sPortName, 9600, Parity.None, 8, StopBits.One);
									Form1.mySerialPort.ReadTimeout = 500;
									Form1.mySerialPort.WriteTimeout = 500;
									Form1.mySerialPort.DtrEnable = true;
									Form1.mySerialPort.RtsEnable = true;
									try
									{
										Form1.mySerialPort.Open();
									}
									catch
									{
									}
								}
								bFound = true;
							}
						}
						else if (sInstanceName.IndexOf(this.Vid_Pid) > -1)
						{
							if (!this.isConnected)
							{
								sPortName = queryObj["PortName"].ToString();
								Form1.mySerialPort = new SerialPort(sPortName, 9600, Parity.None, 8, StopBits.One);
								Form1.mySerialPort.ReadTimeout = 500;
								Form1.mySerialPort.WriteTimeout = 500;
								Form1.mySerialPort.DtrEnable = true;
								Form1.mySerialPort.RtsEnable = true;
							}
							bFound = true;
						}
						else
						{
							bFound = false;
						}
					}
				}
				catch (ManagementException)
				{
				}
			}
			return bFound;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00003E4C File Offset: 0x0000204C
		private void sendToArduino(string arduinoData)
		{
			if (this.AutomaticPortSelect)
			{
				if (!this.isConnected)
				{
					return;
				}
				if (!Form1.mySerialPort.IsOpen)
				{
					try
					{
						Form1.mySerialPort.Open();
					}
					catch (Exception)
					{
					}
				}
				if (!Form1.mySerialPort.IsOpen)
				{
					return;
				}
				try
				{
					Form1.mySerialPort.WriteLine(arduinoData);
					return;
				}
				catch (Exception ex)
				{
					ex.ToString().IndexOf("device is not connected");
					this.isConnected = false;
					return;
				}
			}
			if (this.ManualPortSelect && this.manualIsAttached)
			{
				if (!Form1.mySerialPort.IsOpen)
				{
					try
					{
						Form1.mySerialPort.Open();
					}
					catch (Exception)
					{
					}
				}
				try
				{
					Form1.mySerialPort.WriteLine(arduinoData);
				}
				catch (Exception ex2)
				{
					ex2.ToString();
				}
			}
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00003F30 File Offset: 0x00002130
		private string getDeviceName(string port)
		{
			if (port == "COM1")
			{
				return "System Port";
			}
			string regexPattern = "\\D*(\\d+)\\D*";
			port = "COM" + Regex.Replace(port, regexPattern, "$1");
			string empty = string.Empty;
			string deviceName = string.Empty;
			string empty2 = string.Empty;
			string empty3 = string.Empty;
			ManagementObjectSearcher searcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_PnPEntity WHERE ClassGuid='{4d36e978-e325-11ce-bfc1-08002be10318}'");
			try
			{
				foreach (ManagementBaseObject managementBaseObject in searcher.Get())
				{
					ManagementObject queryObj = (ManagementObject)managementBaseObject;
					if (queryObj["Name"].ToString().Contains(port))
					{
						deviceName = queryObj["Description"].ToString();
					}
				}
				if (deviceName == string.Empty)
				{
					deviceName = "(Name Not Available)";
				}
			}
			catch
			{
				deviceName = "(Name Not Available)";
			}
			return deviceName;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x0000402C File Offset: 0x0000222C
		private string getVidPid(string port)
		{
			if (port == "COM1")
			{
				return "VID_0000&PID_0000";
			}
			string regexPattern = "\\D*(\\d+)\\D*";
			port = "COM" + Regex.Replace(port, regexPattern, "$1");
			string empty = string.Empty;
			string sPortDeviceID = string.Empty;
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_PnPEntity WHERE ClassGuid='{4d36e978-e325-11ce-bfc1-08002be10318}'").Get())
			{
				ManagementObject QueryObj = (ManagementObject)managementBaseObject;
				if (QueryObj["Name"].ToString().Contains(port))
				{
					sPortDeviceID = QueryObj["PNPDeviceID"].ToString();
					if (sPortDeviceID.Contains("BTHENUM"))
					{
						int indexOfBT = sPortDeviceID.IndexOf("_");
						sPortDeviceID = sPortDeviceID.Substring(0, indexOfBT);
					}
					else
					{
						int indexOfVIDPID = sPortDeviceID.IndexOf("VID");
						sPortDeviceID = sPortDeviceID.Substring(indexOfVIDPID, 17);
					}
				}
			}
			return sPortDeviceID;
		}

		// Token: 0x06000020 RID: 32 RVA: 0x0000412C File Offset: 0x0000232C
		private string getDeviceID(string port)
		{
			if (port == "COM1")
			{
				return "SystemPort";
			}
			string regexPattern = "\\D*(\\d+)\\D*";
			port = "COM" + Regex.Replace(port, regexPattern, "$1");
			string deviceID = string.Empty;
			string sPortDeviceID = string.Empty;
			string empty = string.Empty;
			string empty2 = string.Empty;
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_PnPEntity WHERE ClassGuid='{4d36e978-e325-11ce-bfc1-08002be10318}'").Get())
			{
				ManagementObject QueryObj = (ManagementObject)managementBaseObject;
				if (QueryObj["Name"].ToString().Contains(port))
				{
					deviceID = QueryObj["PNPDeviceID"].ToString();
					if (deviceID.Contains("BTHENUM"))
					{
						int indexOfBT = deviceID.IndexOf("_");
						sPortDeviceID = deviceID.Substring(0, indexOfBT);
					}
					else
					{
						int indexOfVIDPID = deviceID.IndexOf("VID");
						int indexOfDevID = deviceID.IndexOf("\\", indexOfVIDPID);
						deviceID.IndexOf("_", indexOfDevID);
						sPortDeviceID = deviceID.Substring(indexOfDevID + 1);
					}
				}
			}
			return sPortDeviceID;
		}

		// Token: 0x06000021 RID: 33 RVA: 0x0000425C File Offset: 0x0000245C
		public void Usb_DeviceRemoved(string deviceNameID)
		{
			if (deviceNameID.IndexOf(this.Vid_Pid) > -1)
			{
				this.isConnected = false;
				this.isAttached = false;
				if (this.AutomaticPortSelect)
				{
					try
					{
						Form1.mySerialPort.Dispose();
						Form1.mySerialPort.Close();
					}
					catch
					{
					}
				}
			}
			if (deviceNameID.IndexOf(this.SPortVid_Pid) > -1)
			{
				this.manualIsAttached = false;
				if (this.ManualPortSelect)
				{
					try
					{
						Form1.mySerialPort.Dispose();
						Form1.mySerialPort.Close();
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06000022 RID: 34 RVA: 0x000042FC File Offset: 0x000024FC
		public void Usb_DeviceAdded(string deviceNameID)
		{
			if (deviceNameID.IndexOf(this.Vid_Pid) > -1)
			{
				Thread.Sleep(1000);
				this.isAttached = true;
			}
			if (deviceNameID.IndexOf(this.SPortVid_Pid) > -1)
			{
				Thread.Sleep(1000);
				if (this.ManualPortSelect)
				{
					this.Selected_Serial(this.portSelected);
				}
			}
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00004358 File Offset: 0x00002558
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if (m.Msg == 537)
			{
				int num = (int)m.WParam;
				if (num != 32768)
				{
					if (num == 32772)
					{
						Form1.DEV_BROADCAST_DEVICEINTERFACE hdrOut = (Form1.DEV_BROADCAST_DEVICEINTERFACE)m.GetLParam(typeof(Form1.DEV_BROADCAST_DEVICEINTERFACE));
						this.Usb_DeviceRemoved(hdrOut.dbcc_name);
						return;
					}
				}
				else
				{
					Form1.DEV_BROADCAST_DEVICEINTERFACE hdrIn = (Form1.DEV_BROADCAST_DEVICEINTERFACE)m.GetLParam(typeof(Form1.DEV_BROADCAST_DEVICEINTERFACE));
					this.Usb_DeviceAdded(hdrIn.dbcc_name);
				}
			}
		}

		// Token: 0x06000024 RID: 36 RVA: 0x000043DC File Offset: 0x000025DC
		public void checkDevice()
		{
			string sInstanceName = string.Empty;
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_PnPEntity WHERE ClassGuid='{4d36e978-e325-11ce-bfc1-08002be10318}'").Get())
			{
				sInstanceName = ((ManagementObject)managementBaseObject)["PNPDeviceID"].ToString().ToUpper();
				if (sInstanceName.IndexOf(this.Vid_Pid) > -1)
				{
					if (sInstanceName.IndexOf(Form1.devID) > -1)
					{
						this.isAttached = true;
					}
					else
					{
						this.isAttached = true;
					}
				}
			}
			if (this.isAttached)
			{
				this.isConnected = this.ConnectToDevice();
			}
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00004490 File Offset: 0x00002690
		private void Exit_Click(object sender, EventArgs e)
		{
			try
			{
				if (Form1.mySerialPort.IsOpen)
				{
					Form1.mySerialPort.Close();
				}
			}
			catch
			{
			}
			base.Dispose();
			Application.Exit();
		}

		// Token: 0x06000026 RID: 38 RVA: 0x000044D4 File Offset: 0x000026D4
		public static void CreateINIData()
		{
			new IniData();
			IniData createData = new IniData();
			FileIniDataParser fileIniDataParser = new FileIniDataParser();
			createData.Sections.AddSection("DeviceConfig");
			createData.Sections.GetSectionData("DeviceConfig").LeadingComments.Add("This is the configuration file for the Application");
			createData.Sections.GetSectionData("DeviceConfig").Keys.AddKey("VendorID", "0000");
			createData.Sections.GetSectionData("DeviceConfig").Keys.AddKey("ProductID", "0000");
			createData.Sections.GetSectionData("DeviceConfig").Keys.AddKey("DeviceID", "0");
			createData.Sections.GetSectionData("DeviceConfig").Keys.AddKey("isBT", "false");
			createData.Sections.GetSectionData("DeviceConfig").Keys.AddKey("BTDevice", "");
			fileIniDataParser.WriteFile("Config.ini", createData, null);
		}

		// Token: 0x06000027 RID: 39 RVA: 0x000045E8 File Offset: 0x000027E8
		public static void ModifyINIData(string name, string value)
		{
			int RetryTimes = 0;
			while (!File.Exists("Config.ini"))
			{
				if (RetryTimes != 0)
				{
					return;
				}
				Form1.CreateINIData();
				RetryTimes = 1;
			}
			FileIniDataParser fileIniDataParser = new FileIniDataParser();
			IniData modifiedData = fileIniDataParser.ReadFile("Config.ini");
			modifiedData["DeviceConfig"][name] = value;
			fileIniDataParser.WriteFile("Config.ini", modifiedData, null);
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00004640 File Offset: 0x00002840
		public static string ReadINIData(string name)
		{
			string readIniData = null;
			int RetryTimes = 0;
			while (!File.Exists("Config.ini"))
			{
				if (RetryTimes != 0)
				{
					return readIniData;
				}
				Form1.CreateINIData();
				RetryTimes = 1;
			}
			return new FileIniDataParser().ReadFile("Config.ini")["DeviceConfig"][name];
		}

		// Token: 0x0400000B RID: 11
		private static bool isBT = Convert.ToBoolean(Form1.ReadINIData("isBT"));

		// Token: 0x0400000C RID: 12
		private static string BTDevice = Convert.ToString(Form1.ReadINIData("BTDevice"));

		// Token: 0x0400000D RID: 13
		private static int dataCheckInterval = 3000;

		// Token: 0x0400000E RID: 14
		private static string VID = Convert.ToString(Form1.ReadINIData("VendorID"));

		// Token: 0x0400000F RID: 15
		private static string PID = Convert.ToString(Form1.ReadINIData("ProductID"));

		// Token: 0x04000010 RID: 16
		private static string devID = Convert.ToString(Form1.ReadINIData("DeviceID"));

		// Token: 0x04000011 RID: 17
		private Computer thisComputer;

		// Token: 0x04000012 RID: 18
		private string Vid_Pid = "VID_" + Form1.VID + "&PID_" + Form1.PID;

		// Token: 0x04000013 RID: 19
		private string SPortVid_Pid = string.Empty;

		// Token: 0x04000014 RID: 20
		private bool isConnected;

		// Token: 0x04000015 RID: 21
		private bool isAttached;

		// Token: 0x04000016 RID: 22
		private bool manualIsAttached;

		// Token: 0x04000017 RID: 23
		private string portSelected = string.Empty;

		// Token: 0x04000018 RID: 24
		private bool AutomaticPortSelect = true;

		// Token: 0x04000019 RID: 25
		private bool ManualPortSelect;

		// Token: 0x0400001A RID: 26
		private static SerialPort mySerialPort;

		// Token: 0x0400001B RID: 27
		private NotifyIcon ApplicationIcon;

		// Token: 0x0400001C RID: 28
		private Icon trayIcon;

		// Token: 0x0400001D RID: 29
		private System.Windows.Forms.Timer connectionTimer1 = new System.Windows.Forms.Timer();

		// Token: 0x0400001E RID: 30
		private ContextMenuStrip menu = new ContextMenuStrip();

		// Token: 0x02000008 RID: 8
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		internal struct DEV_BROADCAST_DEVICEINTERFACE
		{
			// Token: 0x04000029 RID: 41
			public int dbcc_size;

			// Token: 0x0400002A RID: 42
			public int dbcc_devicetype;

			// Token: 0x0400002B RID: 43
			public int dbcc_reserved;

			// Token: 0x0400002C RID: 44
			public Guid dbcc_classguid;

			// Token: 0x0400002D RID: 45
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 255)]
			public string dbcc_name;
		}
	}
}
