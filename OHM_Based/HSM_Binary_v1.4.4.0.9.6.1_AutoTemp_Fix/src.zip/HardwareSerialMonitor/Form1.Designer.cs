﻿namespace HardwareSerialMonitor
{
	// Token: 0x02000003 RID: 3
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000029 RID: 41 RVA: 0x0000468C File Offset: 0x0000288C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600002A RID: 42 RVA: 0x000046AC File Offset: 0x000028AC
		private void InitializeComponent()
		{
			base.SuspendLayout();
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(8f, 16f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.None;
			base.ClientSize = new global::System.Drawing.Size(289, 154);
			this.DoubleBuffered = true;
			base.Name = "Form1";
			this.Text = "Form1";
			base.ResumeLayout(false);
		}

		// Token: 0x0400001F RID: 31
		private global::System.ComponentModel.IContainer components;
	}
}
