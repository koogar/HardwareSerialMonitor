
Wee Hardware Stat Server (Gnat-Stats & Phat-Stats Compatible)
Copyright (C) 2021  Vinod Mishra
-----------------------------------

Edit the appsettings.json 

  "SerialPortSettings": {
    "Port": "COM3",  //Change to your Specific Arduino port


Copy the InstallService.bat & DeleteService.bat files in the main root folder (WeeHardwareStatServer.exe Folder)

To install WeeHardwareStatServer windows background service: 

Run the InstallService.bat as Admin to install the windows background service (runs silent at startup)

To Uninstall WeeHardwareStatServer:

Run DeleteService.bat as Admin.

Warning!!!:
 
      You Must have a fixed folder location before you install the service. 
      If you want to move the folder you have to delete the service first, then move the folder.
      You can then install service again from the new location.

